/**
 * Enhanced Player class with precise timing control
 * Uses RequestAnimationFrame for more accurate timing
 */
class Player {
    constructor(slides) {
        this.slides = slides;
        this.currentSlide = 1;
        this.slidesCount = slides.length;
        this.slideItems = [];
        this.isGlobalString = false;
        this.globalSlide = [];
        this.globalSlideNum = 0;
        
        // Timing variables
        this.slideStartTime = 0;
        this.slideDuration = 0;
        this.animationFrameId = null;
        this.isSlidePlaying = false;
        this._lastVideoElement = null;    // yeni əlavə
        
        // Reference to video element
        this.videoElement = null;
        Logger.info("Player initialized.", { slideCount: slides.length }); //
    }

    stopPlayer() {
        Logger.info("Player stopping."); //
        // Stop animation frame
        if (this.animationFrameId) {
            cancelAnimationFrame(this.animationFrameId);
            this.animationFrameId = null;
            Logger.info("Animation frame cancelled."); //
        }
        
        // Stop video and release hardware decoder
        if (this.videoElement) {
            try {
                this.videoElement.pause();
                this.videoElement.removeAttribute('src');
                this.videoElement.load();
            } catch (e) { /* ignore */ }
            Logger.info("Video stopped and decoder released."); //
            this.videoElement = null;
        }
        if (this._lastVideoElement) {
            try {
                this._lastVideoElement.pause();
                this._lastVideoElement.removeAttribute('src');
                this._lastVideoElement.load();
            } catch (e) { /* ignore */ }
            this._lastVideoElement = null;
        }
        
        // Reset state
        this.slides = [];
        this.currentSlide = 1;
        this.isGlobalString = false;
        this.globalSlide = [];
        this.isSlidePlaying = false;
        Logger.info("Player state reset."); //
        
        // Clear any existing content
        let contentWrap = document.getElementById("content-wrap");
        if (contentWrap) {
            contentWrap.innerHTML = "";
            Logger.info("Content container cleared."); //
        }
    }

    startPlayer() {
        Logger.info("Player starting."); //
        // Initialize player
        this.processSlides();
        this.currentSlide = 1;
        Logger.info("Processed slides array, total after processing:", { slidesCount: this.slides.length }); //
        this.showSlide(this.currentSlide);
    }
    
    processSlides() {
        Logger.info("Processing slides to extract globaltext and filter slides."); //
        let newArray = [];
        for (let i = 0; i < this.slides.length; i++) {
            let hasGlobalText = false;
            let hasOtherContent = false;
            for (let i2 = 0; i2 < this.slides[i].items.length; i2++) {
                if (this.slides[i].items[i2].type_content === "globaltext") {
                    this.isGlobalString = true;
                    this.globalSlide = this.slides[i].items[i2];
                    hasGlobalText = true;
                    Logger.info("Found globaltext in slide", { slideIndex: i, globalTextItem: this.globalSlide }); //
                } else {
                    hasOtherContent = true;
                }
            }
            // Only add slide if it has content other than globaltext
            if (hasOtherContent || !hasGlobalText) {
                newArray.push(this.slides[i]);
            } else {
                Logger.info("Filtering out globaltext-only slide", { slideIndex: i }); //
            }
        }
        this.slides = newArray;
        this.slidesCount = this.slides.length;
        Logger.info("Slides array updated, new count:", { slidesCount: this.slidesCount }); //
    }

    showSlide(slideIndex) {
        Logger.info(`Showing slide ${slideIndex}.`); //
        if (!this.slides || this.slides.length === 0 || slideIndex > this.slides.length) {
            console.error("Invalid slide index or no slides available");
            Logger.error("Invalid slide index or no slides available", { slideIndex, slidesLength: this.slides ? this.slides.length : 0 }); //
            return;
        }
        
        // Stop previous animation frame if running
        if (this.animationFrameId) {
            cancelAnimationFrame(this.animationFrameId);
            this.animationFrameId = null;
            Logger.info("Previous animation frame cancelled before showing new slide."); //
        }
        
        // Get current slide data
        const slideData = this.slides[slideIndex - 1];
        const slideItems = slideData.items;
        
        // Get slide duration (in milliseconds)
        this.slideDuration = (slideData.duration || 5) * 1000; // Convert to milliseconds, default 5s
        Logger.info("Slide duration set (ms):", { slideDuration: this.slideDuration }); //
        
        // Create container for the next slide
        this.prepareNextSlideContainer(slideItems);
    }
    
    prepareNextSlideContainer(slideItems) {
        Logger.info("Preparing container for next slide.", { itemCount: slideItems.length }); //
        // Get current content container
        const currentContainer = document.getElementById("content-wrap");
        
        // Create new container for next slide
        const nextContainer = document.createElement("div");
        nextContainer.id = "next-content-wrap";
        nextContainer.style.position = "absolute";
        nextContainer.style.top = "0";
        nextContainer.style.left = "0";
        nextContainer.style.width = "100%";
        nextContainer.style.height = "100%";
        nextContainer.style.opacity = "0";
        nextContainer.style.zIndex = currentContainer ? (parseInt(currentContainer.style.zIndex || "0") + 1).toString() : "1";
        
        // Add to document
        if (currentContainer) {
            currentContainer.parentNode.insertBefore(nextContainer, currentContainer.nextSibling);
            Logger.info("Inserted next slide container into DOM above current container."); //
        } else {
            document.body.appendChild(nextContainer);
            Logger.info("No current container found; appended next container to body."); //
        }
        
        // Load all content for the slide
        this.loadSlideContent(nextContainer, slideItems);
    }
    
    loadSlideContent(container, slideItems) {
        Logger.info("Loading slide content into container.", { slideItemsCount: slideItems.length }); //
        // Track if we're loading media that needs to complete
        let mediaLoading = false;
        const mediaElements = [];
        
        // Add global text if exists
        if (this.isGlobalString) {
            const globalTextElement = this.addTextElement(this.globalSlide);
            container.appendChild(globalTextElement);
            Logger.info("Appended global text element to slide container."); //
        }
        
        // Add all slide items
        for (const item of slideItems) {
            let element = null;
            
            switch (item.type_content) {
                case "text":
                case "globaltext":
                    Logger.info("Adding text element to slide.", { item }); //
                    element = this.addTextElement(item);
                    break;
                case "video":
                    Logger.info("Adding video element to slide.", { url: item.attr.location }); //
                    element = this.addVideoElement(item);
                    mediaLoading = true;
                    mediaElements.push(element);
                    // Store reference to video
                    this.videoElement = element;
                    break;
                case "image":
                    Logger.info("Adding image element to slide.", { url: item.attr.location }); //
                    element = this.addImageElement(item);
                    mediaLoading = true;
                    mediaElements.push(element);
                    break;
                case "site":
                    Logger.info("Adding URL (iframe) element to slide.", { url: item.attr.url }); //
                    element = this.addURLElement(item);
                    break;
                case "table":
                    Logger.info("Adding table element to slide."); //
                    element = this.addTableElement(item);
                    break;
                default:
                    Logger.warn("Unknown item type, skipping element creation.", { type: item.type_content }); //
            }
            
            if (element) {
                container.appendChild(element);
                Logger.info("Appended element to slide container.", { elementType: item.type_content }); //
            }
        }
        
        if (mediaLoading) {
            Logger.info("Media detected in slide; waiting for media load events."); //
            this.waitForMediaLoad(container, mediaElements);
        } else {
            Logger.info("No media in slide; transitioning to next slide immediately."); //
            this.transitionToNextSlide(container);
        }
    }
    
    waitForMediaLoad(container, mediaElements) {
        Logger.info("waitForMediaLoad started.", { mediaElementsCount: mediaElements.length }); //
        let loadedCount = 0;
        const totalElements = mediaElements.length;
        let transitioned = false;
        
        const doTransition = () => {
            if (transitioned) return;
            transitioned = true;
            Logger.info("All media elements have loaded successfully."); //
            this.transitionToNextSlide(container);
        };
        
        const checkAllLoaded = () => {
            if (loadedCount >= totalElements) {
                doTransition();
            }
        };
        
        // Set up load handlers for each media element
        mediaElements.forEach(element => {
            if (element.tagName.toLowerCase() === 'img') {
                if (element.complete) {
                    loadedCount++;
                    Logger.info("Image element was already complete."); //
                    checkAllLoaded();
                } else {
                    element.onload = () => {
                        loadedCount++;
                        Logger.info("Image element loaded."); //
                        checkAllLoaded();
                    };
                    element.onerror = () => {
                        console.error("Failed to load image");
                        Logger.error("Image failed to load, continuing with fallback.", { src: element.src }); //
                        loadedCount++;
                        checkAllLoaded();
                    };
                }
            } else if (element.tagName.toLowerCase() === 'video') {
                if (element.readyState >= 3) { // HAVE_FUTURE_DATA
                    loadedCount++;
                    Logger.info("Video element already ready."); //
                    checkAllLoaded();
                } else {
                    element.oncanplay = () => {
                        loadedCount++;
                        Logger.info("Video element ready to play."); //
                        checkAllLoaded();
                    };
                    element.onerror = (e) => {
                        // Only count as loaded if src is already set to a proper URI
                        // Ignore errors from empty or pending src (Tizen async resolve)
                        if (element.src && element.src.indexOf('file://') !== -1) {
                            console.error("Failed to load video");
                            Logger.error("Video failed to load, continuing with fallback.", { src: element.src }); //
                            loadedCount++;
                            checkAllLoaded();
                        } else {
                            Logger.warn("Video error ignored - waiting for Tizen filesystem resolve.", { src: element.src }); //
                        }
                    };
                }
            }
        });
        
        // Safety timeout - if media doesn't load within 15 seconds, continue anyway
        setTimeout(() => {
            if (!transitioned) {
                console.warn("Some media elements didn't load in time, continuing anyway");
                Logger.warn("Media load timeout reached; transitioning slide despite incomplete loads.", { loadedCount, totalElements }); //
                doTransition();
            }
        }, 15000);
    }
    
    transitionToNextSlide(nextContainer) {
    	  Logger.info("Transitioning to next slide.");
    	  const currentContainer = document.getElementById("content-wrap");

    	  // CRITICAL FIX: Release old video decoder BEFORE starting new video
    	  // Tizen has only 1 hardware video decoder - must free it first
    	  const oldVideo = this._lastVideoElement;
    	  if (oldVideo) {
    	    try {
    	      oldVideo.pause();
    	      oldVideo.removeAttribute('src');
    	      oldVideo.load(); // releases the hardware decoder
    	      Logger.info("Old video stopped and decoder released.");
    	    } catch (e) {
    	      Logger.warn("Error releasing old video.", { error: e.message });
    	    }
    	  }

    	  // Keçid effektləri
    	  nextContainer.style.transition = "opacity 0.3s ease-in-out";
    	  nextContainer.style.opacity = "1";
    	  if (currentContainer) {
    	    currentContainer.style.transition = "opacity 0.3s ease-in-out";
    	    currentContainer.style.opacity = "0";
    	  }

    	  setTimeout(() => {
    	    // Köhnə konteyneri sil, yeni konteyneri əsasla
    	    if (currentContainer) currentContainer.remove();
    	    nextContainer.id = "content-wrap";

    	    const newVideo = this.videoElement;
    	    this._lastVideoElement = newVideo;

    	    if (newVideo) {
    	      try {
    	        newVideo.currentTime = 0;
    	      } catch (e) { /* ignore */ }

    	      const playPromise = newVideo.play();
    	      if (playPromise !== undefined) {
    	        playPromise
    	          .then(() => {
    	            Logger.info("New video started playing.");
    	          })
    	          .catch(err => {
    	            if (err.name !== 'AbortError') {
    	              console.error("Video play error:", err);
    	              Logger.error("Error playing video element after transition.", { error: err.message });
    	            }
    	          });
    	      }
    	    }

    	    // Slayd üçün dəqiq timer-i yenidən başladın
    	    this.startPreciseTimer();
    	  }, 300); // keçid müddəti
    	}
    
    startPreciseTimer() {
        // Record exact start time
        this.slideStartTime = performance.now();
        this.isSlidePlaying = true;
        Logger.info("Precise timer started.", { slideStartTime: this.slideStartTime, slideDuration: this.slideDuration }); //
        
        // Use requestAnimationFrame for more precise timing
        const checkTime = (timestamp) => {
            if (!this.isSlidePlaying) {
                Logger.info("Precise timer canceled, no longer checking time."); //
                return;
            }
            
            // Calculate elapsed time
            const elapsed = timestamp - this.slideStartTime;
            
            // If it's time to change slides
            if (elapsed >= this.slideDuration) {
                Logger.info("Slide duration elapsed, advancing to next slide.", { elapsed, slideDuration: this.slideDuration }); //
                this.isSlidePlaying = false;
                this.goToNextSlide();
            } else {
                // Continue checking time
                this.animationFrameId = requestAnimationFrame(checkTime);
            }
        };
        
        // Start animation frame loop
        this.animationFrameId = requestAnimationFrame(checkTime);
    }
    
    goToNextSlide() {
        Logger.info("Going to next slide.", { currentSlide: this.currentSlide, totalSlides: this.slidesCount }); //
        if (this.currentSlide === this.slidesCount) {
            this.currentSlide = 1;
        } else {
            this.currentSlide++;
        }
        Logger.info("Updated currentSlide index.", { newCurrentSlide: this.currentSlide }); //
        
        this.showSlide(this.currentSlide);
    }
    
    // The original element creation methods
    addTextElement(element) {
        Logger.info("addTextElement invoked.", { element }); //
        let elementWrap = document.createElement("div");
        elementWrap.style.position = "absolute";
        elementWrap.style.width = element.width + "px";
        elementWrap.style.backgroundColor = element.attr.frame_bg_color || "transparent";
        elementWrap.style.color = element.attr.color || "#000000";
        elementWrap.style.top = element.top + "px";
        elementWrap.style.left = element.left + "px";
        if (element.attr.font_size) {
            elementWrap.style.fontSize = element.attr.font_size + "px";
        }
        elementWrap.style.height = element.height + "px ";
        elementWrap.style.overflow = "hidden";
        elementWrap.style.zIndex = element.index;
        if(element.attr.is_scrolling) {
            let el = document.createElement("marquee")
            el.direction = element.attr.direction;
            el.scrollAmount = element.attr.speed;
            let innerText = element.attr.textarea.replace("font - size", "font-size");
            innerText = innerText.replace(" px", "px");
            el.innerHTML = innerText;
            elementWrap.append(el);
            Logger.info("Created scrolling text element (marquee)."); //
        } else {
            let innerText = element.attr.textarea.replace("font - size", "font-size");
            innerText = innerText.replace(" px", "px");
            elementWrap.innerHTML = innerText;
            Logger.info("Created static text element."); //
        }
        return elementWrap;
    }

    addVideoElement(element) {
        Logger.info("addVideoElement invoked.", { url: element.attr.location }); //
        let elementWrap = document.createElement("video");
        elementWrap.id = "video";
        elementWrap.setAttribute("type", "video/mp4");
        // No autoplay - playback is controlled manually in transitionToNextSlide
        elementWrap.controls = false;
        elementWrap.setAttribute("playsinline", "");
        elementWrap.setAttribute("preload", "auto");
        elementWrap.muted = true;
        Logger.info("Video element set to muted for autoplay compliance."); //
        elementWrap.style.position = "absolute";
        elementWrap.style.top = element.top + "px";
        elementWrap.style.left = element.left + "px";
        elementWrap.style.fontSize = "14px";
        elementWrap.style.height = "100%";
        elementWrap.style.zIndex = element.index;
        elementWrap.style.width = "100%";
        elementWrap.style.objectFit = "contain";
        elementWrap.style.backgroundColor = "#000";
        
        try {
            if (typeof tizen !== 'undefined' && tizen.filesystem) {
                Logger.info("Resolving video file via Tizen filesystem to get URI."); //
                tizen.filesystem.resolve(
                    element.attr.location,
                    function (file) {
                        const uri = tizen.filesystem.toURI(file.fullPath);
                        elementWrap.src = uri;
                        Logger.info("Video element source updated to filesystem URI.", { uri }); //
                    },
                    function (err) {
                        console.error("Video resolve error:", err.message);
                        Logger.error("Error resolving video file path via Tizen filesystem.", { error: err.message }); //
                        // Fallback: try raw path
                        elementWrap.src = element.attr.location;
                    },
                    "r"
                );
            } else {
                // Non-Tizen fallback
                elementWrap.src = element.attr.location;
            }
        } catch (e) {
            console.error("Unexpected error during video element setup:", e.message);
            Logger.error("Unexpected exception in addVideoElement.", { error: e.message }); //
            elementWrap.src = element.attr.location;
        }
        
        return elementWrap;
    }

    addImageElement(element) {
        Logger.info("addImageElement invoked.", { url: element.attr.location }); //
        let elementWrap = document.createElement("img");
        elementWrap.style.position = "absolute";
        elementWrap.style.top = element.top + "px";
        elementWrap.style.left = element.left + "px";
        elementWrap.style.fontSize = "14px";
        elementWrap.style.height = "100%";
        elementWrap.style.zIndex = element.index;
        elementWrap.style.width = "100%";
        elementWrap.src = element.attr.location;
        Logger.info("Image element created with src.", { src: element.attr.location }); //
        return elementWrap;
    }

    addURLElement(element) {
        Logger.info("addURLElement invoked.", { url: element.attr.url }); //
        let elementWrap = document.createElement("iframe");
        elementWrap.style.top = element.top + "px";
        elementWrap.style.left = element.left + "px";
        elementWrap.style.fontSize = "14px";
        elementWrap.style.position = "absolute";
        elementWrap.style.top = "0";
        elementWrap.style.left = "0";
        elementWrap.style.width = "100vw";
        elementWrap.style.height = "100vh";
        elementWrap.style.zIndex = element.index;
        elementWrap.src = element.attr.url;
        elementWrap.setAttribute("allowfullscreen", "true");
        elementWrap.setAttribute("allow", "autoplay; fullscreen; encrypted-media");
        Logger.info("URL iframe element created.", { src: element.attr.url }); //
        return elementWrap;
    }

    addTableElement(item) {
        Logger.info("addTableElement invoked."); //
        const div = document.createElement("div");
        const table = document.createElement("table");
        div.style.backgroundColor = item.attr.bg_color || "transparent";
        table.style.tableLayout = "fixed";

        // Positioning and sizing: using the first value from display_types
        const borderColor = (item.attr.borderColor) ? item.attr.borderColor : "#ffa102";
        if(item.display_types && item.display_types.length) {
          const display = item.display_types[0];
          div.style.position = "absolute";
          div.style.top = display.top + "px";
          div.style.left = display.left + "px";
          div.style.width = display.width + "px";
          div.style.height = display.height + "px";
          div.style.zIndex = item.index || 1;
          table.style.width = "100%";
          Logger.info("Table container styled with display_types.", { display }); //
        }
        table.style.border = "1px solid " + borderColor;

        // Table header (thead)
        if(item.attr.columns && item.attr.columns.length) {
          const thead = document.createElement("thead");
          const headerRow = document.createElement("tr");
          const columnsCount = item.attr.columns.length;
          const percentWidth = (100 / columnsCount).toFixed(2) + "%";
          item.attr.columns.forEach(column => {
            const th = document.createElement("th");
            const p = document.createElement("p");
            p.classList.add("m-0");
            p.textContent = column.text;
            th.style.border = "1px solid " + borderColor;
            th.style.width = percentWidth;
            th.style.backgroundColor = column.attr.backgroundColor;
            // Apply style properties
            Object.assign(p.style, {
              color: column.attr.color,
              fontSize: column.attr.fontSize + "px",
              fontStyle: column.attr.fontStyle,
              textAlign: column.attr.textAlign
            });
            th.appendChild(p);
            headerRow.appendChild(th);
          });
          thead.appendChild(headerRow);
          table.appendChild(thead);
          Logger.info("Table header constructed.", { columnsCount: item.attr.columns.length }); //
        }

        // Table body (tbody)
        if(item.attr.rows && item.attr.rows.length) {
          const tbody = document.createElement("tbody");
          item.attr.rows.forEach(row => {
            const tr = document.createElement("tr");
            row.forEach(cell => {
              const td = document.createElement("td");
              td.style.border = "1px solid " + borderColor;
              td.style.backgroundColor = cell.attr.backgroundColor;
              const p = document.createElement("p");
              p.classList.add("m-0");
              p.textContent = cell.text;
              Object.assign(p.style, {
                color: cell.attr.color,
                fontSize: cell.attr.fontSize + "px",
                fontStyle: cell.attr.fontStyle,
                textAlign: cell.attr.textAlign
              });
              td.appendChild(p);
              tr.appendChild(td);
            });
            tbody.appendChild(tr);
          });
          table.appendChild(tbody);
          Logger.info("Table body constructed.", { rowsCount: item.attr.rows.length }); //
        }
        div.appendChild(table);
        Logger.info("Table element appended to div container."); //
        return div;
    }
}
